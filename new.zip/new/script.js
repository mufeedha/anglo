(function(){
  
  var app = angular.module('StudentApp',[]);
  app.controller('DataController',function(){
  this.record=StudentData;
});
var StudentData=[
   {
     "name":"Anu",

     "rollno":101,

     "dept":"cse",

      "mark":500,
},
  {
    "name":"Beena",

     "rollno":102,

     "dept":"cse",

      "mark":400,
},

 {
  "name":"Chandra",

   "rollno":103,

    "dept":"ece",

    "mark":400,
},

 {
   "name":"Heera",

    "rollno":104,

    "dept":"eee",

     "mark":200,
}, 
{
   "name":" Indhu",

    "rollno":105,

    "dept":"cse",

     "mark":500,
},
 
{
  "name":"jeena",
 
   "rollno":106,

      "dept":"cse",

       "mark":500,
},

{
  "name":"kareena",

   "rollno":107,

    "dept":"cse",

    "mark":600,
},

{
   "name":"Leena",

    "rollno":108,

    "dept":"cse",

     "mark":700,
},

{
   "name":"meera",

    "rollno":109,

     "dept":"cse",

      "mark":800,
},

{
   "name":"Neena",

    "rollno":110,

     "dept":"cse",

      "mark":540,
},

{
   "name":"prabhu",

    "rollno":111,

     "dept":"cse",

      "mark":530,
},

{
   "name":"preeja",

    "rollno":112,

     "dept":"cse",

      "mark":543,
},

{
  "name":"Rani",

   "rollno":113,

   "dept":"cse",

     "mark":542,
},

{ 
"name":"Rini",

 "rollno":114,

  "dept":"cse",

    "mark":435,
},
 
{
   "name":"Rinto",

    "rollno":115,

     "dept":"cse",

       "mark":532,
},

{

"name":"sanu",
"rollno":116,

 "dept":"cse",

 "mark":250,
},

{

"name":"sara",

 "rollno":117,

 "dept":"cse",

  "mark":500,
},

{
"name":"Sheeba",

 "rollno":118,

  "dept":"cse",

  "mark":564,
},

{
"name":"teena",

 "rollno":119,

 "dept":"cse",

 "mark":500,
},

{
"name":"Zara",

"rollno":120,

"dept":"cse",

"mark":500,
}
];


})();